package com.example.lym_proyect

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
